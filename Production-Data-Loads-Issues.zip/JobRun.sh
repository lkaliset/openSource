db.ContractSummaries_03_02.aggregate([ { $match: {} }, { $out: "ContractSummaries_03_07_incr" } ]) 


mongo  -u pointnext-itgusr -p Txentn109 --host mongodb://hc4t02655.itcs.hpecorp.net:20001,hc4t02656.itcs.hpecorp.net:20001/pointnext-itg?replicaSet=eapmongo01i --authenticationDatabase pointnext-itg 

Assets_03_07_incr

db.Assets_03_07_incr.aggregate([ { $match: {} }, { $out: "Assets_03_07_incr_Lakshman" } ]) 


nohup /usr/hdp/current/spark2-client/bin/spark-submit --class collections.AssetsMapping --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 10G --num-executors 20 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=4G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/AssetsMapping-log-`date +%Y%m%d%H%M%S`.txt &

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class collections.AssetsMappingIncremental --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 10G --num-executors 20 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=4G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/AssetsMappingIncremental-log-`date +%Y%m%d%H%M%S`.txt &

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class collections.AssetsMappingIncremental --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 10G --num-executors 80 --driver-memory 20G --conf spark.yarn.executor.memoryOverhead=5G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/AssetsMappingIncremental-log-`date +%Y%m%d%H%M%S`.txt &

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class collections.AssetsMapping --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 10G --num-executors 80 --driver-memory 20G --conf spark.yarn.executor.memoryOverhead=5G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/AssetsMapping-log-`date +%Y%m%d%H%M%S`.txt &

cd /home/kalisett/pn-cr

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class collections.AccountSummariesMappingSeparateRead --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 10G --num-executors 10 --driver-memory 30G --conf spark.yarn.executor.memoryOverhead=2G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/AccountSummariesMappingSeparateRead-log-`date +%Y%m%d%H%M%S`.txt &

hadoop fs -rm -r /user/srvc_pointnext_ibeap_hitg/perf_debug/AccountSummariesMapping/df
hadoop fs -rm -r /user/srvc_pointnext_ibeap_hitg/perf_debug/AccountSummariesMapping/df_formated

hadoop fs -ls /user/srvc_pointnext_ibeap_hitg/perf_debug/AccountSummariesMapping/df_formated|cat|wc -l
hadoop fs -du -s -h /user/srvc_pointnext_ibeap_hitg/perf_debug/AccountSummariesMapping/df_formated
hadoop fs -du -h /user/srvc_pointnext_ibeap_hitg/perf_debug/AccountSummariesMapping/df_formated
  
  println("Lakshman Before df : "+LocalDateTime.now())
    df.write.json("/user/srvc_pointnext_ibeap_hitg/perf_debug/AccountSummariesMapping/df")
    println("Lakshman After df : "+LocalDateTime.now())

	
show collections
db.AccountSummaries.getIndexes()
db.AccountSummaries.count()
1281578
db.AccountSummaries.remove( { } )
db.AccountSummaries.count()
0

show collections
db.ContractSummaries.getIndexes()
db.ContractSummaries.count()
1281578
db.ContractSummaries.remove( { } )
db.ContractSummaries.count()
0

show collections
db.Assets_02_16.getIndexes()
db.Assets_02_16.count()
db.Assets_02_16.remove( { } )
db.Assets_02_16.count()

----------------------
SELECT COUNT(*)
FROM
  (SELECT CASE
              WHEN (final_support_status_flag IS NULL) THEN NULL
              WHEN (final_support_status_flag LIKE '%Flex%'
                    OR final_support_status_flag LIKE '%Annuity%'
                    OR final_support_status_flag LIKE '%Active Contract%'
                    OR final_support_status_flag LIKE '%Expired Contract%') THEN service_document_number
              WHEN (final_support_status_flag LIKE '%Fixed%') THEN carepack_serial_number_id
              WHEN (final_support_status_flag LIKE '%Non Stop Contract%') THEN cabs_system_number
              ELSE NULL
          END AS CONTRACT_ID
   FROM IB_PANHPE_ENR) AS PHE
WHERE CONTRACT_ID IS NULL;

36156551
36212755


cd /home/kalisett/pn-cr
cp ibnext.properties /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr
cp hive.properties /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr
cp error.properties /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr
cp mongo.properties /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr
cd /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr
chmod 755 *.*
rm /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr/scripts/jars/pn-cr.jar
cp /home/kalisett/pn-cr/scripts/jars/pn-cr.jar /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr/scripts/jars
cd /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr/scripts/jars
chmod 755 *.*

cd /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr/logs

rm /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr/jobs/ingest_cabs_full.sh
cp /home/kalisett/pn-cr/jobs/ingest_cabs_full.sh /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr/jobs
chmod 755 /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr/jobs/ingest_cabs_full.sh

cd /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr
nohup jobs/ingest_cabs_full.sh etc/conf/cabs.properties PRO > logs/ingest_cabs_full-log-`date +%Y%m%d%H%M%S`.txt &



nohup /usr/hdp/current/spark2-client/bin/spark-submit --class collections.UsersMapping --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 10G --num-executors 20 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=2G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/UsersMapping-log-`date +%Y%m%d%H%M%S`.txt &

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class collections.ContractSummariesMappingSeparateRead --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 10G --num-executors 20 --driver-memory 30G --conf spark.yarn.executor.memoryOverhead=2G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/ContractSummariesMappingSeparateRead-log-`date +%Y%m%d%H%M%S`.txt &

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class collections.AssetsMappingSeparateRead --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 10G --num-executors 20 --driver-memory 30G --conf spark.yarn.executor.memoryOverhead=2G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/AssetsMappingSeparateRead-log-`date +%Y%m%d%H%M%S`.txt &

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class collections.AssetsMappingSeparateRead --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 20 --driver-memory 20G --conf spark.yarn.executor.memoryOverhead=5G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/AssetsMappingSeparateRead-log-`date +%Y%m%d%H%M%S`.txt &

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class collections.ContractSummariesMappingSeparateRead --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 40 --driver-memory 20G --conf spark.yarn.executor.memoryOverhead=5G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/ContractSummariesMappingSeparateRead-log-`date +%Y%m%d%H%M%S`.txt &

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class collections.ContractSummariesMappingSeparateRead --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 10G --num-executors 20 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=2G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/ContractSummariesMappingSeparateRead-log-`date +%Y%m%d%H%M%S`.txt &

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class collections.AssetsMappingSeparateRead --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 40 --driver-memory 20G --conf spark.yarn.executor.memoryOverhead=5G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/AssetsMappingSeparateRead-log-`date +%Y%m%d%H%M%S`.txt &

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class collections.AccountSummariesMappingSeparateRead --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 40 --driver-memory 20G --conf spark.yarn.executor.memoryOverhead=5G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr-as.jar > logsdir/AccountSummariesMappingSeparateRead-log-`date +%Y%m%d%H%M%S`.txt &

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class collections.AccountSummariesMappingSeparateRead --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 40 --driver-memory 20G --conf spark.yarn.executor.memoryOverhead=5G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr-debug.jar > logsdir/AccountSummariesMappingSeparateRead-log-`date +%Y%m%d%H%M%S`.txt &

cd /home/kalisett/pn-cr

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class mycomp.ProcessMyComp --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 30G --num-executors 10 --driver-memory 20G --conf spark.yarn.executor.memoryOverhead=10G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/ProcessMyComp-log-`date +%Y%m%d%H%M%S`.txt &

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class mycomp.ProcessMyComp --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 30G --num-executors 10 --driver-memory 20G --conf spark.yarn.executor.memoryOverhead=10G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/ProcessMyComp-log-`date +%Y%m%d%H%M%S`.txt &


SELECT COUNT(*) FROM  EA_IB.salesroster_enr;


nohup /usr/hdp/current/spark2-client/bin/spark-submit --class salesroster.MergeMyCompSFDC --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 10G --num-executors 10 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=2G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/MergeMyCompSFDC-log-`date +%Y%m%d%H%M%S`.txt &

SELECT COUNT(*) FROM  EA_IB.salesroster_enr;

------------------------------------------------------------------------------
SELECT COUNT(*) FROM  EA_IB.ib_panhpe_contact_enr;

cd /home/kalisett/pn-cr

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class panhpe.CreateContactsTable --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 10G --num-executors 10 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=2G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/CreateContactsTable-log-`date +%Y%m%d%H%M%S`.txt &

SELECT COUNT(*) FROM  EA_IB.ib_panhpe_contact_enr;
------------------------------------------------------------------------------

rm -r /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr
mkdir /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr
cd /home/kalisett
cp -r pn-cr/* /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr/
chmod 755 /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr/jobs/*
chmod 755 /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr/etc/conf/*

cd /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr/tools

java -jar password1.jar "srvc_pointnext_ibeap_hpro" "/HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr/tmp/mycomp_db_pwd" "password_2018#"
java -jar PasswordEncrypt.jar "srvc_pointnext_ibeap_hpro" "/HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr/tmp/cabs_db_pwd" "@db_build_2017"


java -jar PasswordEncrypt.jar "srvc_pointnext_ibeap_hpro" "/HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr/tmp/mycomp_db_pwd" "password_2018#"
java -jar PasswordEncrypt.jar "srvc_pointnext_ibeap_hpro" "/HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr/tmp/cabs_db_pwd" "@db_build_2017"

hadoop fs -rm -r /user/srvc_pointnext_ibeap_hpro/passwords
hadoop fs -mkdir /user/srvc_pointnext_ibeap_hpro/passwords

hadoop fs -rm -r /user/srvc_pointnext_ibeap_hpro/passwords/mycomp_db_pwd
hadoop fs -rm -r /user/srvc_pointnext_ibeap_hpro/passwords/cabs_db_pwd

hadoop fs -copyFromLocal /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr/tmp/mycomp_db_pwd /user/srvc_pointnext_ibeap_hpro/passwords
hadoop fs -copyFromLocal /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr/tmp/cabs_db_pwd /user/srvc_pointnext_ibeap_hpro/passwords

/home/kalisett/pn-cr/tmp

hadoop fs -mkdir /user/srvc_pointnext_ibeap_hpro/passwords

hadoop fs -copyFromLocal /home/kalisett/pn-cr/tmp/mycomp_db_pwd /user/srvc_pointnext_ibeap_hpro/passwords
hadoop fs -copyFromLocal /home/kalisett/pn-cr/tmp/cabs_db_pwd /user/srvc_pointnext_ibeap_hpro/passwords

------------------------------------------------------------------------------
# Modify \pn-cr\config\ibnext.properties with proper values for run mode(TEST/CLUSTER) and Hive DB name
# Modify \pn-cr\config\hive.properties with proper hive table names(customers2 and ib_panhpe_units_rw_ext_tst)
# Modify the code in IntelliJ, as required and build the Artifact
# Copy the jar and \pn-cr\config folder to /home/bohidarb/pn-cr
# All the jobs are to be executed only after the source Raw tables are populated
------------------------------------------------------------------------------
cd /HDFS_ROOT/user/srvc_pointnext_ibeap_hpro/pn-cr
cd /home/kalisett/pn-cr
------------------------------------------------------------------------------
nohup jobs/ingest_cabs_full.sh etc/conf/cabs.properties PRO > logs/ingest_cabs_full-log-`date +%Y%m%d%H%M%S`.txt &
nohup jobs/ingest_mycomp_full.sh etc/conf/mycomp.properties PRO > logs/ingest_mycomp_full-log-`date +%Y%m%d%H%M%S`.txt &
------------------------------------------------------------------------------
# Step 1
# Dependencies - None
------------------------------------------------------------------------------
SELECT COUNT(*) FROM EA_IB.mycomp_ref;

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class mycomp.ProcessMyComp --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 60 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=10G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/ProcessMyComp-log-`date +%Y%m%d%H%M%S`.txt &

SELECT COUNT(*) FROM EA_IB.mycomp_ref;

------------------------------------------------------------------------------
# Step 2 - All jobs can be executed in parallel
# Dependencies - None
------------------------------------------------------------------------------
SELECT COUNT(*) FROM EA_IB.sfdc_role_ref;
SELECT COUNT(*) FROM EA_IB.sfdc_salesterritory_ref;
SELECT COUNT(*) FROM EA_IB.sfdc_salesterritory_userassignment_ref;
SELECT COUNT(*) FROM EA_IB.sfdc_user_ref;

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class sfdc.ProcessSalesTerritory --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 60 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=10G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/ProcessSalesTerritory-log-`date +%Y%m%d%H%M%S`.txt &

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class sfdc.ProcessSalesTerritoryUserAssignment --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 60 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=10G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/ProcessSalesTerritoryUserAssignment-log-`date +%Y%m%d%H%M%S`.txt &

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class sfdc.ProcessUser --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 60 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=10G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/ProcessUser-log-`date +%Y%m%d%H%M%S`.txt &

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class sfdc.ProcessUserRole --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 60 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=10G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/ProcessUserRole-log-`date +%Y%m%d%H%M%S`.txt &

SELECT COUNT(*) FROM EA_IB.sfdc_role_ref;
SELECT COUNT(*) FROM EA_IB.sfdc_salesterritory_ref;
SELECT COUNT(*) FROM EA_IB.sfdc_salesterritory_userassignment_ref;
SELECT COUNT(*) FROM EA_IB.sfdc_user_ref;
------------------------------------------------------------------------------
# Step 3
# Dependencies - Step 2
------------------------------------------------------------------------------
SELECT COUNT(*) FROM EA_IB.sfdc_enr;

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class sfdc.ConsolidateSFDC --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 60 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=10G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/ConsolidateSFDC-log-`date +%Y%m%d%H%M%S`.txt &

SELECT COUNT(*) FROM EA_IB.sfdc_enr;
------------------------------------------------------------------------------
# Step 4
# Dependencies - Step 1 and Step 3
------------------------------------------------------------------------------
SELECT COUNT(*) FROM  EA_IB.salesroster_enr;

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class salesroster.MergeMyCompSFDC --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 60 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=10G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/MergeMyCompSFDC-log-`date +%Y%m%d%H%M%S`.txt &

SELECT COUNT(*) FROM  EA_IB.salesroster_enr;
------------------------------------------------------------------------------
# Step 5 - All jobs can be executed in parallel
# Dependencies - None
------------------------------------------------------------------------------
SELECT COUNT(*) FROM  EA_IB.ib_panhpe_customers_ref;
SELECT COUNT(*) FROM  EA_IB.ib_panhpe_products_ref;
SELECT COUNT(*) FROM  EA_IB.ib_panhpe_units_ref;

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class panhpe.ProcessCustomers --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 60 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=10G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/ProcessCustomers-log-`date +%Y%m%d%H%M%S`.txt &

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class panhpe.ProcessProducts --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 60 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=10G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/ProcessProducts-log-`date +%Y%m%d%H%M%S`.txt &

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class panhpe.ProcessUnits --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 60 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=10G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/ProcessUnits-log-`date +%Y%m%d%H%M%S`.txt &

SELECT COUNT(*) FROM  EA_IB.ib_panhpe_customers_ref;
SELECT COUNT(*) FROM  EA_IB.ib_panhpe_products_ref;
SELECT COUNT(*) FROM  EA_IB.ib_panhpe_units_ref;
------------------------------------------------------------------------------
# Step 6
# Dependencies - Step 5
------------------------------------------------------------------------------
SELECT COUNT(*) FROM  EA_IB.ib_panhpe_enr;

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class panhpe.ConsolidatePanHPE --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 30G --num-executors 20 --driver-memory 20G --conf spark.yarn.executor.memoryOverhead=10G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/ConsolidatePanHPE-log-`date +%Y%m%d%H%M%S`.txt &

SELECT COUNT(*) FROM  EA_IB.ib_panhpe_enr;
# Step 7
# Dependencies - Step 4 and Step 6
------------------------------------------------------------------------------
SELECT COUNT(*) FROM  EA_IB.ibcr_enr;

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class salesrosterpanhpe.MergeSalesRosterPanHPE --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 60 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=10G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/MergeSalesRosterPanHPE-log-`date +%Y%m%d%H%M%S`.txt &

SELECT COUNT(*) FROM  EA_IB.ibcr_enr;
------------------------------------------------------------------------------
# Step 8 - All jobs can be executed in parallel
# Dependencies - Step 7
------------------------------------------------------------------------------
nohup /usr/hdp/current/spark2-client/bin/spark-submit --class collections.UsersMapping --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 60 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=10G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/UsersMapping-log-`date +%Y%m%d%H%M%S`.txt &

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class collections.AccountSummariesMapping --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 60 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=10G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/AccountSummariesMapping-log-`date +%Y%m%d%H%M%S`.txt &

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class collections.AssetsMapping --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 60 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=10G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/AssetsMapping-log-`date +%Y%m%d%H%M%S`.txt &

cd /home/kalisett/pn-cr

nohup /usr/hdp/current/spark2-client/bin/spark-submit --class collections.ContractSummariesMappingSeparateRead --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 60 --driver-memory 10G --conf spark.yarn.executor.memoryOverhead=10G --conf spark.speculation=true --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/ContractSummariesMappingSeparateRead-log-`date +%Y%m%d%H%M%S`.txt &
------------------------------------------------------------------------------
# Step 9
# Dependencies - ???
------------------------------------------------------------------------------
nohup /usr/hdp/current/spark2-client/bin/spark-submit --class calculations.CalculationMetrics --queue srvc_pointnext --executor-cores 5 --master yarn --deploy-mode cluster --executor-memory 20G --num-executors 60 --driver-memory 10G --files /etc/spark/conf/hive-site.xml,ibnext.properties#config/ibnext.properties,hive.properties#config/hive.properties,mongo.properties#config/mongo.properties,error.properties#config/error.properties pn-cr.jar > logsdir/CalculationMetrics-log-`date +%Y%m%d%H%M%S`.txt &
------------------------------------------------------------------------------
