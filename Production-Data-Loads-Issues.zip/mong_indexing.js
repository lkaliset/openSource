// Source config
var collection_name = "Assets_20180315";
var target = 360000000;
var elmt = new Array();
elmt[6] = 0;
var sum = 0;
var last = 0;
for( var i = 0; i < elmt.length; i++ ){
                sleep(5000);
                elmt[i] = db[collection_name].count();
                sleep(5000);
                var last = db[collection_name].count()
                elmt[i] = (last - elmt[i])/5;
                sum += elmt[i];
}

var speed = sum/elmt.length;
var etat = target/speed;

var date = new Date(null);
date.setSeconds(etat); // specify value for SECONDS here
var result = date.toISOString().substr(11, 8);


print("Current progress for "+ collection_name + " collection:");
print("Writing records per second: "+speed);
print("Current record count: "+last + " / "+ target);
print("ETA of finshing job: "+ result);




// Source config

var collection_name = "Users",
    index_fields = [
      "userId"
    ];

	
var collection_name = "AccountSummaries",
    index_fields = [
      "customerId",
	  "userList"
    ];

var collection_name = "ContractSummaries",
    index_fields = [
      "contractId",
	  "userList"
    ];

var collection_name = "Assets",
    index_fields = [
      "contractId",
	  "customerId",
	  "opportunityId",
	  "salesTerritoryId"
    ];

// create uri for database connection
var test_doc = new Object(),
    index_len = index_fields.length;
for (var i = 0; i < index_len; i++) {
  test_doc[index_fields[i]] = "";
}
// insert test document
db[collection_name].insert(test_doc);

for (var i = 0; i < index_len; i++) {
// specific Index that needs sparse option to be true.
  if (index_fields[i] === "opportunityId") {
    print("Create index " + index_fields[i] + " for collection " + collection_name);
    db[collection_name].createIndex({[index_fields[i]]: 1 },{sparse: true});
    }
  else {
    print("Create index " + index_fields[i] + " for collection " + collection_name);
    db[collection_name].createIndex({[index_fields[i]]: 1 });
    }
}

if (collection_name === "Assets") {
    db[collection_name].createIndex({customerId: 1 , contractId: 1});
    db[collection_name].createIndex({customerId: 1 , contractEndDate: 1});
}

// remove test document
db[collection_name].remove(test_doc);
